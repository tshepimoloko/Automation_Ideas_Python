# Make sure to fill in your spotify client_secret information
spotify_token = ""
spotify_user_id = ""